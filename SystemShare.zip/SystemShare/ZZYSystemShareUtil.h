//
//  ZZYSystemShareUtil.h
//
//  Created by zzy on 2018/1/3.
//  Copyright © 2018年. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZYSystemShareUtil : NSObject

/**
 * 分享图片和视屏
 * @param fileList 需要分享的内容（以数组的形式传进来）。如：需要分享两张图片，数组中就是两个图片的对象。
 * @param currentViewController 弹出分享弹框所在的控制器
 * @param sourceView 分享弹框箭头的位置（只有在iPad上生效）
 */
+ (void)sharePictureAndVideoWithFileList:(NSArray *)fileList currentViewController:(id)currentViewController sourceView:(UIButton *)sourceView;

/**
 * 关闭分享视图（由于系统分享视图是一个控制器，当需要present其他控制器时，检测到系统分享视图存在，就不会present新的控制器了）
 */
+ (void)closeShareControllerWithCurrentViewController:(UIViewController *)currentViewController;

@end
