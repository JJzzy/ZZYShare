//
//  ZZYSystemShareUtil.m
//
//  Created by zzy on 2018/1/3.
//  Copyright © 2018年. All rights reserved.
//

#import "UVSystemShareUtil.h"
#import <MessageUI/MFMailComposeViewController.h>

@implementation ZZYSystemShareUtil

+ (void)sharePictureAndVideoWithFileList:(NSArray *)fileList currentViewController:(id)currentViewController sourceView:(UIButton *)sourceView {
    
    NSMutableArray *activityItems = [ZZYSystemShareUtil separateFileWithFileList:fileList];
    if (!activityItems || !activityItems.count) {
        UVILog(@"share content is nil");
        return;
    }
    
    UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItems applicationActivities:nil];
    
    /*
      去除一些不需要的图标选项，如："com.apple.UIKit.activity.Open.Copy.com.tencent.xin"、“com.apple.UIKit.activity.Open.Copy.com.kugou.kugou1002”
      通过“com.apple.UIKit.activity.Open.Copy”前缀过滤“用**导入”的分享平台，次方法只适用于iOS10，不适用于iOS11、12.
     */
    //屏蔽不需要显示的平台，如微信、酷狗等
//    activityVC.excludedActivityTypes = @[@"com.apple.UIKit.activity.Open.Copy.com.tencent.xin", @"com.apple.UIKit.activity.Open.Copy.com.kugou.kugou1002", @"com.apple.UIKit.activity.RemoteOpenInApplication-ByCopy"];
    
    //成功失败的回调block
    UIActivityViewControllerCompletionWithItemsHandler myBlock = ^(UIActivityType __nullable activityType, BOOL completed, NSArray * __nullable returnedItems, NSError * __nullable activityError) {
        NSLog(@"systemShare ActivityType:%@  Completed:%d  Items:%@  Error:%@", activityType, completed, returnedItems, activityError);
        if ([activityType isEqualToString:@"com.apple.UIKit.activity.Message"] ||
            [activityType isEqualToString:@"com.apple.UIKit.activity.Mail"] ||
            [activityType isEqualToString:@"com.apple.UIKit.activity.PostToFacebook"] ||
            [activityType isEqualToString:@"com.apple.UIKit.activity.PostToTwitter"]) {
            if (completed){
                NSLog(@"succeed");
            } else {
                NSLog(@"failed");
            }
        }
    };
    activityVC.completionWithItemsHandler = myBlock;
    
    if (UIDevice.currentDevice.userInterfaceIdiom != UIUserInterfaceIdiomPhone) {
        //iPad下必须对以下属性重定义，否则会崩溃
        UIPopoverPresentationController *popover = activityVC.popoverPresentationController;
        if (popover != nil) {
            popover.sourceView = sourceView;
            popover.sourceRect = sourceView.bounds;
            popover.permittedArrowDirections = UIPopoverArrowDirectionAny;
        }
    }
    if ([[NSThread currentThread] isMainThread]){
        [currentViewController presentViewController:activityVC animated:YES completion:nil];
    } else {
        dispatch_sync(dispatch_get_main_queue(), ^{
            [currentViewController presentViewController:activityVC animated:YES completion:nil];
        });
    }
}

//将需要分享的内容进行分类添加
+ (NSMutableArray *)separateFileWithFileList:(NSArray *)filelist {
    NSMutableArray *activityItems = [[NSMutableArray alloc]init];
    for (id file in filelist) {
        //压缩文件。此处判断条件需修改
        if ([file isKindOfClass:[NSString class]]) {
            NSURL *fileUrl = [NSURL fileURLWithPath:(NSString *)file];
            [activityItems addObject:fileUrl];
            continue;
        }
        //图片文件（UIImage）
        if ([file isKindOfClass:[UIImage class]]) {
            [activityItems addObject:file];
            continue;
        }
        //文字（NSString）:发送纯文字使用以下方法
        if ([file isKindOfClass:[NSString class]]) {
            [activityItems removeAllObjects];
            [activityItems addObject:alarmStr];
            continue;
        }
        //录像文件
        if (bean.isVideo) {
            //录像文件（NSURL）
            NSURL *urlVideo = [NSURL fileURLWithPath:bean.path];
            [activityItems addObject:urlVideo];
        } else {
            //图片文件（UIImage）
            UIImage *image = [UIImage imageWithContentsOfFile:bean.path];
            [activityItems addObject:image];
        }
    }
    return activityItems;
}

//获取currentViewController上的系统分享控制器、其他present的控制器视图、弹框controller，并隐藏。否则新界面无法弹出
+ (void)closeShareControllerWithCurrentViewController:(UIViewController *)currentViewController {

    UIViewController *vc = [UVSystemShareUtil getTheTopViewController:currentViewController];
    if (vc != currentViewController) {
        [vc dismissViewControllerAnimated:YES completion:nil];
    }
}

//使用递归的方式获取当前控制器最上面的presentedViewController
+ (UIViewController *)getTheTopViewController:(UIViewController *)vc {
    if (vc.presentedViewController == nil) {
        return vc;
    }
    return [self getTheTopViewController:vc.presentedViewController];
}

@end
